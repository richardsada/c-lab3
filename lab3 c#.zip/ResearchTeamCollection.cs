﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab3
{
    public class ResearchTeamCollection<TKey>
    {
        // Закрытые поля согласно заданию
        private readonly Dictionary<TKey, ResearchTeam> _researchTeams = new Dictionary<TKey, ResearchTeam>();
        private readonly KeySelector<TKey> _keySelector;

        
         public delegate TKey KeySelector<TKey>(ResearchTeam rt);

        // Конструктор с параметром KeySelector
        public ResearchTeamCollection(KeySelector<TKey> keySelector)
        {
            _keySelector = keySelector;
        }

        // Метод добавления элементов по умолчанию
        public void AddDefaults(int count = 2)
        {
            for (int i = 0; i < count; i++)
            {
                var rt = new ResearchTeam();
                _researchTeams[_keySelector(rt)] = rt;
            }
        }

        // Метод добавления произвольных элементов
        public void AddResearchTeams(params ResearchTeam[] teams)
        {
            foreach (var team in teams)
            {
                var key = _keySelector(team);
                if (_researchTeams.ContainsKey(key))
                    throw new ArgumentException($"Ключ {key} уже существует");
                _researchTeams[key] = team;
            }
        }

        // Переопределенный ToString()
        public override string ToString()
        {
            return string.Join("\n\n",
                _researchTeams.Select(pair =>
                    $"Ключ: {pair.Key}\n{pair.Value.ToString()}"
                ));
        }

        // Метод ToShortString()
        public string ToShortString()
        { // cto to ne to
            return string.Join("\n",
                _researchTeams.Select(pair =>
                    $"Ключ: {pair.Key}\n" +
                    $"Организация: {pair.Value.Organisation}\n" +
                    $"Тема: {pair.Value.Theme}\n" +
                    $"Участников: {pair.Value.ProjectParticipants.Count}\n" +
                    $"Публикаций: {pair.Value.Publications.Count}"
                ));
        }

        // Свойство LastPublicationDate
        public DateTime LastPublicationDate =>
            _researchTeams.Values
                .SelectMany(rt => rt.Publications)
                .Select(p => p._TimeOfPublication)
                .DefaultIfEmpty(DateTime.MinValue)
                .Max();

        // Метод TimeFrameGroup
        public IEnumerable<KeyValuePair<TKey, ResearchTeam>> TimeFrameGroup(TimeFrame value)
        {
            return _researchTeams
                .Where(pair => pair.Value.ResearchDuration == value)
                .OrderBy(pair => pair.Key);
        }

        // Свойство GroupByTimeFrame
        public IEnumerable<IGrouping<TimeFrame, KeyValuePair<TKey, ResearchTeam>>> GroupByTimeFrame =>
            _researchTeams
                .GroupBy(pair => pair.Value.ResearchDuration)
                .OrderBy(g => g.Key);

        // Дополнительные методы для работы с коллекцией
        public IEnumerable<ResearchTeam> GetResearchTeamsSortedByDate()
        {
            return _researchTeams.Values.OrderBy(rt => rt.ResearchDuration);
        }

        public IEnumerable<ResearchTeam> GetResearchTeamsSortedByPublicationsCount()
        {
            return _researchTeams.Values.OrderByDescending(rt => rt.Publications.Count);
        }
    }

}
