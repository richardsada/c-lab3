﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// pochistit kommenti  i GenerateNonExistentKey()    
namespace Lab3
{
    // Универсальный делегат для генерации элементов
    public delegate KeyValuePair<TKey, TValue> GenerateElement<TKey, TValue>(int j);

    public class TestCollections<TKey, TValue>
    {
        // Коллекции для тестирования
        private List<TKey> _listTKey;
        private List<string> _listString;
        private Dictionary<TKey, TValue> _dictTKeyTValue;
        private Dictionary<string, TValue> _dictStringTValue;
        private readonly GenerateElement<TKey, TValue> _generateElement;

        // Конструктор
        public TestCollections(int count, GenerateElement<TKey, TValue> generator)
        {
            if (count <= 0)
                throw new ArgumentException("Количество элементов должно быть больше 0.");

            _generateElement = generator ?? throw new ArgumentNullException(nameof(generator));
            InitializeCollections(count);
        }

        // Инициализация коллекций
        private void InitializeCollections(int count)
        {
            _listTKey = new List<TKey>();
            _listString = new List<string>();
            _dictTKeyTValue = new Dictionary<TKey, TValue>();
            _dictStringTValue = new Dictionary<string, TValue>();

            for (int j = 0; j < count; j++)
            {
                var element = _generateElement(j);
                _listTKey.Add(element.Key);
                _listString.Add(element.Key.ToString());
                _dictTKeyTValue[element.Key] = element.Value;
                _dictStringTValue[element.Key.ToString()] = element.Value;
            }
        }

        // Измерение времени поиска
        public void MeasureSearchTime()
        {
            var elementsToSearch = new[]
            {
                _listTKey[0],                   // Первый элемент
                _listTKey[_listTKey.Count / 2], // Центральный элемент
                _listTKey[^1],                  // Последний элемент
                //GenerateNonExistentKey()        // Несуществующий элемент
            };

            foreach (var key in elementsToSearch)
            {
                MeasureListSearch(key);
                MeasureDictSearch(key);
                MeasureValueSearch(key);
                Console.WriteLine(new string('-', 50));
            }
        }

        // Замер времени поиска в списках
        private void MeasureListSearch(TKey key)
        {
            var sw = Stopwatch.StartNew();
            bool foundInTKey = _listTKey.Contains(key);
            sw.Stop();
            Console.WriteLine($"List<TKey> поиск [{key}]: {sw.ElapsedTicks} тиков");

            string strKey = key.ToString();
            sw.Restart();
            bool foundInString = _listString.Contains(strKey);
            sw.Stop();
            Console.WriteLine($"List<string> поиск [{strKey}]: {sw.ElapsedTicks} тиков");
        }

        // Замер времени поиска в словарях
        private void MeasureDictSearch(TKey key)
        {
            var sw = Stopwatch.StartNew();
            bool foundKeyInDict = _dictTKeyTValue.ContainsKey(key);
            sw.Stop();
            Console.WriteLine($"Dictionary<TKey, TValue> по ключу [{key}]: {sw.ElapsedTicks} тиков");

            string strKey = key.ToString();
            sw.Restart();
            bool foundStringInDict = _dictStringTValue.ContainsKey(strKey);
            sw.Stop();
            Console.WriteLine($"Dictionary<string, TValue> по ключу [{strKey}]: {sw.ElapsedTicks} тиков");
        }

        // Замер времени поиска значения в словаре
        private void MeasureValueSearch(TKey key)
        {
            TValue value;
            bool keyExists = _dictTKeyTValue.TryGetValue(key, out value);

            if (!keyExists)
                value = GenerateNonExistentValue();

            var sw = Stopwatch.StartNew();
            bool containsValue = _dictTKeyTValue.ContainsValue(value);
            sw.Stop();
            Console.WriteLine($"Dictionary<TKey, TValue> поиск значения [{value}]: {sw.ElapsedTicks} тиков");
        }

        // Генерация несуществующего ключа
        private TKey GenerateNonExistentKey()
        {
            if (typeof(TKey) == typeof(int))
                return (TKey)(object)(_listTKey.Count + 1000);

            if (typeof(TKey) == typeof(string))
                return (TKey)(object)"NonExistentKey_12345";

            //throw new NotSupportedException($"Тип {typeof(TKey)} не поддерживается");
        }

        // Генерация несуществующего значения
        private TValue GenerateNonExistentValue()
        {
            if (typeof(TValue) == typeof(string))
                return (TValue)(object)"NonExistentValue_12345";

            if (typeof(TValue) == typeof(int))
                return (TValue)(object)(-1);

            throw new NotSupportedException($"Тип {typeof(TValue)} не поддерживается");
        }
    }
}
